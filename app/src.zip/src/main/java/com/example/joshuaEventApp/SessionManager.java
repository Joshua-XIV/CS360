package com.example.joshuaEventApp;

import android.content.Context;
import android.content.SharedPreferences;

/*
 * SessionManager.java
 *
 * Stores login state, user information, and simple app preferences
 * such as whether the SMS permission dialog has already been shown.
 *
 */
public class SessionManager {
    private static final String PREFERENCE_NAME = "EventTrackerSession";
    private static final String KEY_USER_ID = "userId";
    private static final String KEY_USERNAME = "username";
    private static final String KEY_SMS_ASKED = "smsAsked";
    private static final int NO_USER = -1;

    private final SharedPreferences prefs;
    private final SharedPreferences.Editor editor;

    public SessionManager(Context context) {
        prefs = context.getSharedPreferences(PREFERENCE_NAME, Context.MODE_PRIVATE);
        editor = prefs.edit();
    }

    // Saves the user's information
    public void login(int userId, String username) {
        editor.putInt(KEY_USER_ID, userId);
        editor.putString(KEY_USERNAME, username);
        editor.apply();
    }

    // Clears all saved sessions data
    public void logout() {
        editor.clear();
        editor.apply();
    }

    public boolean isLoggedIn() {
        return prefs.getInt(KEY_USER_ID, NO_USER) != NO_USER;
    }

    public int getUserId() {
        return prefs.getInt(KEY_USER_ID, NO_USER);
    }

    public String getUsername() {
        return prefs.getString(KEY_USERNAME, null);
    }

    public boolean hasSmsBeenAsked() {
        return prefs.getBoolean(KEY_SMS_ASKED, false);
    }

    public void setSmsAsked() {
        editor.putBoolean(KEY_SMS_ASKED, true);
        editor.apply();
    }
}
